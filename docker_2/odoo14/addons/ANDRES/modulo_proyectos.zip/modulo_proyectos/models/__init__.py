# -*- coding: utf-8 -*-

from . import project_task
from . import project_project
from . import hr_employee
from . import res_usuers
