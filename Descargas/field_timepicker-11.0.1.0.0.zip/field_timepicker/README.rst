=================
Time Picker Field
=================

Time picker for fields, using Wickedpicker.

Installation & Configuration
============================

After installing the module, you can use character fields for reading time input with the help of a time picker.
 When you define the fields in xml, use 'widget="timepicker"' for those fields which you need to use as time fields.


Known issues / Roadmap
======================

* ...

Bug Tracker
===========

Contact odoo@cybrosys.com


Contributors
------------

* Linto CT <linto@cybrosys.in>

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.
