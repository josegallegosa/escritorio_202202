# -*- coding: utf-8 -*-
##############################################################################

{
    'name': 'Structure Legal Service Premium CO',
    'version': '1.0',
    'category': 'Human Resources',
    'description': """

Structure Legal Service Premium CO
=================================================

    """,
    'author': 'Rapid Technologies SAC',
    'website': 'https://www.rapi.tech',
    'depends': ['base','hr_payroll_rg_co'],
    'data': [
        'data/hr_payroll_data_p_l_d_s.xml', 
    ],
    'installable': True,
    'auto_install': False,
}


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
