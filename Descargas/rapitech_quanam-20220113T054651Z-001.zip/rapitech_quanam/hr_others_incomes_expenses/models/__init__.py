# -*- coding: utf-8 -*-
##############################################################################

from . import hr_others_incomes_expenses
