# -*- coding: utf-8 -*-
##############################################################################

from . import hr_vacation
from . import hr_leave_inherit
