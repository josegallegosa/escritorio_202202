# -*- coding: utf-8 -*-
from . import model
from . import hr_contract_inherit