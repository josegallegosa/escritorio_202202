# -*- coding: utf-8 -*-
##############################################################################

from . import model
from . import hr_contract
from . import hr_account_journal_inherit