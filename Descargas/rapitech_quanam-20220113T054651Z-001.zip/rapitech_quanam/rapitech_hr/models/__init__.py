# -*- coding: utf-8 -*-

from . import hr_employee_inherit
from . import res_partner_inherit
from . import hr_contract_inherit
from . import hr_payslip_inherit
from . import hr_salary_rule_inherit
