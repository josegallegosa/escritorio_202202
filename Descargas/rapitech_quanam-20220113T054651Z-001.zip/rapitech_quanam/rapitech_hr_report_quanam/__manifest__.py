# -*- coding: utf-8 -*-s
{
    'name': "Rapitech HR Report Quanam",

    'summary': """
    	Modificaciones Rapitech HR Report Quanam
    """,

    'description': """
        Actualizaciones Rapitech HR Report Quanam
    """,

    'author': "Rapid Technoigies",
    'website': "www.rapi.tech",

    'category': 'Employee',
    'version': '0.3',

    'depends': ['base','hr_payroll'],

    'data': [
        'views/view_report_model_lbs.xml',
        'views/view_report_model_cts.xml',
    ],
}
