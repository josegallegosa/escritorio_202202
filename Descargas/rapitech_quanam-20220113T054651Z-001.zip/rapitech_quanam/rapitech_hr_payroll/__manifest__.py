# -*- coding: utf-8 -*-

{
    'name': 'ACT. HR PAYROLL',
    'category': 'HR',
    'summary': 'Tracking MRP',
    'version': '14.0.1',
    'description': """Actualizacion a modulo HR PAYROLL""",
    'author': 'Rapid Technologies SAC',
    'website': 'https://www.rapi.tech',
    'depends': ['hr_payroll'],
    'data': [
        'views/view.xml',
        'wizards/wizard.xml'
    ],
    'installable': True,
    
}
