# -*- coding: utf-8 -*-
##############################################################################

{
    'name': 'Structure Layoffs CO',
    'version': '1.0',
    'category': 'Human Resources',
    'description': """

Estructura Cesantías
=================================================


    """,
    'author': 'Rapid Technologies SAC',
    'website': 'https://www.rapi.tech',
    'depends': ['base','hr_payroll_rg_co'],
    'data': [
        'data/hr_payroll_data_cesa.xml',

        
    ],
    'installable': True,
    'auto_install': False,
}


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
