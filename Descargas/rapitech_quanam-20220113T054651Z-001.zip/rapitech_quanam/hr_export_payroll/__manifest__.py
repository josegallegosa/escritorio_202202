# -*- coding: utf-8 -*-
##############################################################################

{
    'name': 'HR EXPORT NOMINA',
    'version': '1.0',
    'category': 'Human Resources',
    'description': """

HR EXPORT NOMINA
======================


    """,
    'author': 'Rapid Technologies SAC',
    'website': 'https://www.rapid.tech',
    'depends': ['hr_contract','hr_payroll'],
    'data': [
        'views/view.xml',
    ],
    'installable': True,
    'auto_install': False,
}

