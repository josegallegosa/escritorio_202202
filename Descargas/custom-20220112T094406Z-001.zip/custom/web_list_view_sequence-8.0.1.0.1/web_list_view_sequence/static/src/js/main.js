openerp.web_list_view_sequence = function(instance){

    var module = instance.web;

    openerp_web_list_view_sequence(instance,module);
};